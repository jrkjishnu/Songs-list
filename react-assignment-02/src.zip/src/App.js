import './App.css';
import AllSongs from './Components/AllSongs';
import Data from './Components/data';

function App() {
  return (
    <div className="App">
      {/* <Data/> */}
      <AllSongs/>

    </div>
  );
}

export default App;
