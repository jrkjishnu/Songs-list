import React from 'react'

function About() {
    return (
        <div>
            <h2>About Page: This app displays the Song List</h2>
        </div>
    )
}

export default About
